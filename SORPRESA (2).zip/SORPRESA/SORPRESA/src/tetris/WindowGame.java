package tetris;

import java.util.Scanner;
import javax.swing.JFrame;

public class WindowGame {
    
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
//        logi l=new logi();    
//        l.setVisible(true);
        // new logi();
        String usuario;
        String contrasena;
         System.out.println("Ingrese su usuario");
         usuario=sc.nextLine();
         System.out.println("Ingrese su contraseña");
         contrasena=sc.nextLine();
        new WindowGame();
        
        
    }
    public static final int WIDTH = 445, HEIGHT = 629;

    private Board board;
    private Title title;
    private JFrame window;

    public WindowGame() {

        window = new JFrame("Tetris");
        window.setSize(WIDTH, HEIGHT);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setLocationRelativeTo(null);
        window.setResizable(false);

        board = new Board();
        title = new Title(this);

        window.addKeyListener(board);
        window.addKeyListener(title);

        window.add(title);

        window.setVisible(true);
    }

    public void startTetris() {
        window.remove(title);
        window.addMouseMotionListener(board);
        window.addMouseListener(board);
        window.add(board);
        board.startGame();
        window.revalidate();
    }


}
